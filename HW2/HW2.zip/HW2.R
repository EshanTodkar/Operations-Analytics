# Multiple Linear Regression model (AR(2)) 

library(readr)

# Load the data
data <- read_csv("AR2.csv", col_names = FALSE)
demand <- data$X1

# Preparing the lagged variables for AR(2) model
n <- length(demand)
D_t <- demand[3:n]         # D_t corresponds to the demand starting from t=3
D_t_1 <- demand[2:(n-1)]   # D_t-1 corresponds to the demand at t-1
D_t_2 <- demand[1:(n-2)]   # D_t-2 corresponds to the demand at t-2

# Fit a multiple linear regression model for AR(2)
ar2_model <- lm(D_t ~ D_t_1 + D_t_2)

# Display the model summary to obtain the estimates for β0, β1, and β2
summary(ar2_model)